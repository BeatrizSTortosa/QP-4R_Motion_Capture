joint_friction = 0.01;         % Joint friction
mu_s = 1;                      % Static friction
mu_k = 1;                      % Kinetic friction
contact_stiffness = 1e2;       % Contact stiffness 
slope_angle = 0;               % Angle of the downwards slope

sim('QuadrupedModel_Simulink.slx', 15)

% Tracking centre of mass trajectories:

x = out.com.signals.values(1,:);
y = out.com.signals.values(2,:);
z = out.com.signals.values(3,:);

file_x = 'x_data.txt';
file_y = 'y_data.txt';
file_z = 'z_data.txt';

% Write x values to file
fid = fopen(file_x, 'w');
fprintf(fid, '%f\n', x);
fclose(fid);

% Write y values to file
fid = fopen(file_y, 'w');
fprintf(fid, '%f\n', y);
fclose(fid);

% Write z values to file
fid = fopen(file_z, 'w');
fprintf(fid, '%f\n', z);
fclose(fid);



