% Simscape(TM) Multibody(TM) version: 23.2

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(85).translation = [0.0 0.0 0.0];
smiData.RigidTransform(85).angle = 0.0;
smiData.RigidTransform(85).axis = [0.0 0.0 0.0];
smiData.RigidTransform(85).ID = "";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [-52 102.8 37.309516000000002];  % mm
smiData.RigidTransform(1).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(1).axis = [-1 -0 -0];
smiData.RigidTransform(1).ID = "B[MTzYZz5Mrcoif/lFG:-:M+2eHVvnKNB1MxLZL]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [-52 102.8 37.309516000000002];  % mm
smiData.RigidTransform(2).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(2).axis = [-1 -0 -0];
smiData.RigidTransform(2).ID = "F[MTzYZz5Mrcoif/lFG:-:M+2eHVvnKNB1MxLZL]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [-52 67 37.309516000000002];  % mm
smiData.RigidTransform(3).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(3).axis = [-1 -0 -0];
smiData.RigidTransform(3).ID = "B[M+2eHVvnKNB1MxLZL:-:MdfptBOuobMyMRenb]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-52 67 37.309516000000002];  % mm
smiData.RigidTransform(4).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(4).axis = [-1 -0 -0];
smiData.RigidTransform(4).ID = "F[M+2eHVvnKNB1MxLZL:-:MdfptBOuobMyMRenb]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [52 74.800000000000011 37.309516000000002];  % mm
smiData.RigidTransform(5).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(5).axis = [-1 -0 -0];
smiData.RigidTransform(5).ID = "B[M02Z7wFD2+BwEdrh+:-:M+ZfB3SNIZe8V55is]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [52 74.800000000000011 37.309516000000002];  % mm
smiData.RigidTransform(6).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(6).axis = [-1 -0 -0];
smiData.RigidTransform(6).ID = "F[M02Z7wFD2+BwEdrh+:-:M+ZfB3SNIZe8V55is]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [0 74.800000000000011 -0];  % mm
smiData.RigidTransform(7).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(7).axis = [-1 -0 -0];
smiData.RigidTransform(7).ID = "B[MEhe6EvhF50paFOVB:-:M+ZfB3SNIZe8V55is]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [0 74.800000000000011 -0];  % mm
smiData.RigidTransform(8).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(8).axis = [-1 -0 -0];
smiData.RigidTransform(8).ID = "F[MEhe6EvhF50paFOVB:-:M+ZfB3SNIZe8V55is]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [0 67 -0];  % mm
smiData.RigidTransform(9).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(9).axis = [1 0 0];
smiData.RigidTransform(9).ID = "B[M+ZfB3SNIZe8V55is:-:Md/X0B0TzJAZZ0+Qc]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [0 67 -0];  % mm
smiData.RigidTransform(10).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(10).axis = [1 0 0];
smiData.RigidTransform(10).ID = "F[M+ZfB3SNIZe8V55is:-:Md/X0B0TzJAZZ0+Qc]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [52 67 37.309516000000002];  % mm
smiData.RigidTransform(11).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(11).axis = [1 0 0];
smiData.RigidTransform(11).ID = "B[MdfptBOuobMyMRenb:-:M+ZfB3SNIZe8V55is]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [52 67 37.309516000000002];  % mm
smiData.RigidTransform(12).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(12).axis = [1 0 0];
smiData.RigidTransform(12).ID = "F[MdfptBOuobMyMRenb:-:M+ZfB3SNIZe8V55is]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [-68.563752000000008 7.7999999999999998 -71.299143999999998];  % mm
smiData.RigidTransform(13).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(13).axis = [1 0 0];
smiData.RigidTransform(13).ID = "B[M/CiqqQpBnCskr4+V:-:M3s1jUyctnM5YbsmK]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-68.563752000000008 7.7999999999999998 -71.299143999999998];  % mm
smiData.RigidTransform(14).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(14).axis = [1 0 0];
smiData.RigidTransform(14).ID = "F[M/CiqqQpBnCskr4+V:-:M3s1jUyctnM5YbsmK]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [-47.530155000000001 7.7999999999999998 -2.4399550000000003];  % mm
smiData.RigidTransform(15).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(15).axis = [1 0 0];
smiData.RigidTransform(15).ID = "B[MKJuudjXPn7BM+e8Z:-:M/CiqqQpBnCskr4+V]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-47.530155000000001 7.7999999999999998 -2.4399550000000003];  % mm
smiData.RigidTransform(16).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(16).axis = [1 0 0];
smiData.RigidTransform(16).ID = "F[MKJuudjXPn7BM+e8Z:-:M/CiqqQpBnCskr4+V]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [52 102.8 37.309516000000002];  % mm
smiData.RigidTransform(17).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(17).axis = [-1 -0 -0];
smiData.RigidTransform(17).ID = "B[MWHMBJWHd63yzRE4j:-:M02Z7wFD2+BwEdrh+]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [52 102.8 37.309516000000002];  % mm
smiData.RigidTransform(18).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(18).axis = [-1 -0 -0];
smiData.RigidTransform(18).ID = "F[MWHMBJWHd63yzRE4j:-:M02Z7wFD2+BwEdrh+]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [37.550196 7.7999999999999998 -31.718900000000001];  % mm
smiData.RigidTransform(19).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(19).axis = [1 0 0];
smiData.RigidTransform(19).ID = "B[MXzZbBmkDaKQkFjS8:-:M1/w5YNcix31CdHRM]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [37.548290999999999 7.7999999999999998 -31.717593000000001];  % mm
smiData.RigidTransform(20).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(20).axis = [1 0 0];
smiData.RigidTransform(20).ID = "F[MXzZbBmkDaKQkFjS8:-:M1/w5YNcix31CdHRM]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [24.355056999999999 7.7999999999999998 -22.669684];  % mm
smiData.RigidTransform(21).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(21).axis = [1 0 0];
smiData.RigidTransform(21).ID = "B[MkE/8tQ2r7nvBIxz3:-:M1/w5YNcix31CdHRM]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [24.353151999999998 7.7999999999999998 -22.668377];  % mm
smiData.RigidTransform(22).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(22).axis = [1 0 0];
smiData.RigidTransform(22).ID = "F[MkE/8tQ2r7nvBIxz3:-:M1/w5YNcix31CdHRM]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [-17.371834 7.7999999999999998 -32.888370000000002];  % mm
smiData.RigidTransform(23).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(23).axis = [-1 -0 -0];
smiData.RigidTransform(23).ID = "B[M3s1jUyctnM5YbsmK:-:MynBVfUU+E1te4mPM]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [-17.371834 7.7999999999999998 -32.888370000000002];  % mm
smiData.RigidTransform(24).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(24).axis = [-1 -0 -0];
smiData.RigidTransform(24).ID = "F[M3s1jUyctnM5YbsmK:-:MynBVfUU+E1te4mPM]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [-52 51.399999999999999 37.309516000000002];  % mm
smiData.RigidTransform(25).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(25).axis = [1 0 0];
smiData.RigidTransform(25).ID = "B[M4F6ctRcHkFPCskYT:-:MkpkMRHGYbJLFgS3x]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [-52 51.399999999999999 37.309516000000002];  % mm
smiData.RigidTransform(26).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(26).axis = [1 0 0];
smiData.RigidTransform(26).ID = "F[M4F6ctRcHkFPCskYT:-:MkpkMRHGYbJLFgS3x]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [-52 23.400000000000002 37.309516000000002];  % mm
smiData.RigidTransform(27).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(27).axis = [1 0 0];
smiData.RigidTransform(27).ID = "B[MsVyb6yZkElm/xbGR:-:M4F6ctRcHkFPCskYT]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [-52 23.400000000000002 37.309516000000002];  % mm
smiData.RigidTransform(28).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(28).axis = [1 0 0];
smiData.RigidTransform(28).ID = "F[MsVyb6yZkElm/xbGR:-:M4F6ctRcHkFPCskYT]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [10.048249999999999 39.600000000000001 -30.381453];  % mm
smiData.RigidTransform(29).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(29).axis = [1 0 0];
smiData.RigidTransform(29).ID = "B[MIw35ywh72LKi7AbB:-:M7MXx6AecKpl6IbJ8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [10.048249999999999 39.600000000000001 -30.381453];  % mm
smiData.RigidTransform(30).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(30).axis = [1 0 0];
smiData.RigidTransform(30).ID = "F[MIw35ywh72LKi7AbB:-:M7MXx6AecKpl6IbJ8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(31).translation = [0 47.399999999999999 -0];  % mm
smiData.RigidTransform(31).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(31).axis = [-1 -0 -0];
smiData.RigidTransform(31).ID = "B[MeoV3EVd8sqrVD15c:-:M7MXx6AecKpl6IbJ8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(32).translation = [0 47.399999999999999 -0];  % mm
smiData.RigidTransform(32).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(32).axis = [-1 -0 -0];
smiData.RigidTransform(32).ID = "F[MeoV3EVd8sqrVD15c:-:M7MXx6AecKpl6IbJ8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(33).translation = [-10.048249999999999 110.60000000000001 30.381453];  % mm
smiData.RigidTransform(33).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(33).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(33).ID = "B[MC7DNYQX7c+ZrnvzA:-:MCjqOdb0ZHFImRkI9]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(34).translation = [-10.048249999999999 110.60000000000001 30.381453];  % mm
smiData.RigidTransform(34).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(34).axis = [-1 -0 -0];
smiData.RigidTransform(34).ID = "F[MC7DNYQX7c+ZrnvzA:-:MCjqOdb0ZHFImRkI9]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(35).translation = [45.101800999999995 118.40000000000001 -2.09118];  % mm
smiData.RigidTransform(35).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(35).axis = [-1 -0 -0];
smiData.RigidTransform(35).ID = "B[MLXebeq1y6JZgNbcM:-:MC7DNYQX7c+ZrnvzA]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(36).translation = [45.101800999999995 118.40000000000001 -2.09118];  % mm
smiData.RigidTransform(36).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(36).axis = [-1 -0 -0];
smiData.RigidTransform(36).ID = "F[MLXebeq1y6JZgNbcM:-:MC7DNYQX7c+ZrnvzA]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(37).translation = [3.7392630000000002 118.40000000000001 22.263294999999999];  % mm
smiData.RigidTransform(37).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(37).axis = [-1 -0 -0];
smiData.RigidTransform(37).ID = "B[MRqRTxAU0QSWouB90:-:MC7DNYQX7c+ZrnvzA]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(38).translation = [3.7392630000000002 118.40000000000001 22.263294999999999];  % mm
smiData.RigidTransform(38).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(38).axis = [-1 -0 -0];
smiData.RigidTransform(38).ID = "F[MRqRTxAU0QSWouB90:-:MC7DNYQX7c+ZrnvzA]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(39).translation = [45.101800999999995 110.60000000000001 -2.09118];  % mm
smiData.RigidTransform(39).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(39).axis = [1 0 0];
smiData.RigidTransform(39).ID = "B[MWHMBJWHd63yzRE4j:-:MC7DNYQX7c+ZrnvzA]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(40).translation = [45.101800999999995 110.60000000000001 -2.09118];  % mm
smiData.RigidTransform(40).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(40).axis = [1 0 0];
smiData.RigidTransform(40).ID = "F[MWHMBJWHd63yzRE4j:-:MC7DNYQX7c+ZrnvzA]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(41).translation = [-10.048249999999999 118.40000000000001 30.381453];  % mm
smiData.RigidTransform(41).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(41).axis = [-0.57735026918962584 -0.57735026918962584 -0.57735026918962584];
smiData.RigidTransform(41).ID = "B[MZ5RLa4gP1alk6CCa:-:MC7DNYQX7c+ZrnvzA]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(42).translation = [-10.048249999999999 118.40000000000001 30.381453];  % mm
smiData.RigidTransform(42).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(42).axis = [-1 -0 -0];
smiData.RigidTransform(42).ID = "F[MZ5RLa4gP1alk6CCa:-:MC7DNYQX7c+ZrnvzA]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(43).translation = [-10.048249999999999 86.599999999999994 30.381453];  % mm
smiData.RigidTransform(43).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(43).axis = [1 0 0];
smiData.RigidTransform(43).ID = "B[Mt3FgXT9/aIAVV+Fe:-:MCjqOdb0ZHFImRkI9]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(44).translation = [-10.048249999999999 86.599999999999994 30.381453];  % mm
smiData.RigidTransform(44).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(44).axis = [1 0 0];
smiData.RigidTransform(44).ID = "F[Mt3FgXT9/aIAVV+Fe:-:MCjqOdb0ZHFImRkI9]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(45).translation = [0 78.799999999999997 -0];  % mm
smiData.RigidTransform(45).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(45).axis = [-1 -0 -0];
smiData.RigidTransform(45).ID = "B[Mt3FgXT9/aIAVV+Fe:-:MEhe6EvhF50paFOVB]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(46).translation = [0 78.799999999999997 -0];  % mm
smiData.RigidTransform(46).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(46).axis = [-1 -0 -0];
smiData.RigidTransform(46).ID = "F[Mt3FgXT9/aIAVV+Fe:-:MEhe6EvhF50paFOVB]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(47).translation = [-0.74065199999999998 118.40000000000001 -57.611172000000003];  % mm
smiData.RigidTransform(47).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(47).axis = [-0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(47).ID = "B[MLXebeq1y6JZgNbcM:-:MHmAIyT7gTm8rVmh3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(48).translation = [-0.74065199999999998 118.40000000000001 -57.611172000000003];  % mm
smiData.RigidTransform(48).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(48).axis = [-1 -0 -0];
smiData.RigidTransform(48).ID = "F[MLXebeq1y6JZgNbcM:-:MHmAIyT7gTm8rVmh3]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(49).translation = [2.84328 118.40000000000001 6.2884009999999995];  % mm
smiData.RigidTransform(49).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(49).axis = [1 0 0];
smiData.RigidTransform(49).ID = "B[MHmAIyT7gTm8rVmh3:-:MRqRTxAU0QSWouB90]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(50).translation = [2.84328 118.40000000000001 6.2884009999999995];  % mm
smiData.RigidTransform(50).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(50).axis = [1 0 0];
smiData.RigidTransform(50).ID = "F[MHmAIyT7gTm8rVmh3:-:MRqRTxAU0QSWouB90]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(51).translation = [10.048249999999999 15.6 -30.381453];  % mm
smiData.RigidTransform(51).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(51).axis = [-1 -0 -0];
smiData.RigidTransform(51).ID = "B[MIw35ywh72LKi7AbB:-:MKJuudjXPn7BM+e8Z]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(52).translation = [10.048249999999999 15.6 -30.381453];  % mm
smiData.RigidTransform(52).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(52).axis = [-1 -0 -0];
smiData.RigidTransform(52).ID = "F[MIw35ywh72LKi7AbB:-:MKJuudjXPn7BM+e8Z]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(53).translation = [90.325208000000003 7.7999999999999998 -67.900045000000006];  % mm
smiData.RigidTransform(53).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(53).axis = [-1 -0 -0];
smiData.RigidTransform(53).ID = "B[MJkF9MQs/yTioq4PS:-:MXzZbBmkDaKQkFjS8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(54).translation = [90.330752000000004 7.7999999999999998 -67.91576400000001];  % mm
smiData.RigidTransform(54).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(54).axis = [-1 -0 -0];
smiData.RigidTransform(54).ID = "F[MJkF9MQs/yTioq4PS:-:MXzZbBmkDaKQkFjS8]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(55).translation = [66.385075999999998 7.7999999999999998 -0.014331];  % mm
smiData.RigidTransform(55).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(55).axis = [1 0 0];
smiData.RigidTransform(55).ID = "B[MkE/8tQ2r7nvBIxz3:-:MJkF9MQs/yTioq4PS]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(56).translation = [66.379533000000009 7.7999999999999998 0.0013880000000000001];  % mm
smiData.RigidTransform(56).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(56).axis = [1 0 0];
smiData.RigidTransform(56).ID = "F[MkE/8tQ2r7nvBIxz3:-:MJkF9MQs/yTioq4PS]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(57).translation = [66.379533000000009 15.6 0.0013880000000000001];  % mm
smiData.RigidTransform(57).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(57).axis = [1 0 0];
smiData.RigidTransform(57).ID = "B[MJkF9MQs/yTioq4PS:-:Mu4dm2/molVK9BjjF]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(58).translation = [66.385075999999998 15.6 -0.014331];  % mm
smiData.RigidTransform(58).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(58).axis = [1 0 0];
smiData.RigidTransform(58).ID = "F[MJkF9MQs/yTioq4PS:-:Mu4dm2/molVK9BjjF]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(59).translation = [10.048249999999999 7.7999999999999998 -30.381453];  % mm
smiData.RigidTransform(59).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(59).axis = [1 0 0];
smiData.RigidTransform(59).ID = "B[MkE/8tQ2r7nvBIxz3:-:MKJuudjXPn7BM+e8Z]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(60).translation = [10.048249999999999 7.7999999999999998 -30.381453];  % mm
smiData.RigidTransform(60).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(60).axis = [1 0 0];
smiData.RigidTransform(60).ID = "F[MkE/8tQ2r7nvBIxz3:-:MKJuudjXPn7BM+e8Z]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(61).translation = [-47.530155000000001 15.6 -2.4399550000000003];  % mm
smiData.RigidTransform(61).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(61).axis = [1 0 0];
smiData.RigidTransform(61).ID = "B[MKJuudjXPn7BM+e8Z:-:MsVyb6yZkElm/xbGR]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(62).translation = [-47.530155000000001 15.6 -2.4399550000000003];  % mm
smiData.RigidTransform(62).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(62).axis = [1 0 0];
smiData.RigidTransform(62).ID = "F[MKJuudjXPn7BM+e8Z:-:MsVyb6yZkElm/xbGR]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(63).translation = [-4.5738539999999999 7.7999999999999998 -23.285676000000002];  % mm
smiData.RigidTransform(63).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(63).axis = [1 0 0];
smiData.RigidTransform(63).ID = "B[MynBVfUU+E1te4mPM:-:MKJuudjXPn7BM+e8Z]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(64).translation = [-4.5738539999999999 7.7999999999999998 -23.285676000000002];  % mm
smiData.RigidTransform(64).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(64).axis = [1 0 0];
smiData.RigidTransform(64).ID = "F[MynBVfUU+E1te4mPM:-:MKJuudjXPn7BM+e8Z]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(65).translation = [52 59.200000000000003 37.309516000000002];  % mm
smiData.RigidTransform(65).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(65).axis = [-0.57735026918962584 0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(65).ID = "B[MdfptBOuobMyMRenb:-:MRdTCvrtZxh/K4wT1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(66).translation = [52 59.200000000000003 37.309516000000002];  % mm
smiData.RigidTransform(66).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(66).axis = [-1 -0 -0];
smiData.RigidTransform(66).ID = "F[MdfptBOuobMyMRenb:-:MRdTCvrtZxh/K4wT1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(67).translation = [52 23.400000000000002 37.309516000000002];  % mm
smiData.RigidTransform(67).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(67).axis = [1 0 0];
smiData.RigidTransform(67).ID = "B[Mu4dm2/molVK9BjjF:-:MRdTCvrtZxh/K4wT1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(68).translation = [52 23.400000000000002 37.309516000000002];  % mm
smiData.RigidTransform(68).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(68).axis = [1 0 0];
smiData.RigidTransform(68).ID = "F[Mu4dm2/molVK9BjjF:-:MRdTCvrtZxh/K4wT1]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(69).translation = [-22.615382 118.40000000000001 -57.205078999999998];  % mm
smiData.RigidTransform(69).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(69).axis = [-1 -0 -0];
smiData.RigidTransform(69).ID = "B[MSgXRWfTiK9gAcPPd:-:MXMV9Eqn08eom2L6d]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(70).translation = [-22.615382 118.40000000000001 -57.205078999999998];  % mm
smiData.RigidTransform(70).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(70).axis = [-1 -0 -0];
smiData.RigidTransform(70).ID = "F[MSgXRWfTiK9gAcPPd:-:MXMV9Eqn08eom2L6d]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(71).translation = [-23.825084 118.40000000000001 6.7806280000000001];  % mm
smiData.RigidTransform(71).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(71).axis = [-1 -0 -0];
smiData.RigidTransform(71).ID = "B[MSgXRWfTiK9gAcPPd:-:Md/ldxY9ay6PXaDwt]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(72).translation = [-23.825139 118.40000000000001 6.7834859999999999];  % mm
smiData.RigidTransform(72).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(72).axis = [-1 -0 -0];
smiData.RigidTransform(72).ID = "F[MSgXRWfTiK9gAcPPd:-:Md/ldxY9ay6PXaDwt]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(73).translation = [-66.365560000000002 110.60000000000001 -0.021846999999999998];  % mm
smiData.RigidTransform(73).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(73).axis = [1 0 0];
smiData.RigidTransform(73).ID = "B[MTzYZz5Mrcoif/lFG:-:MXMV9Eqn08eom2L6d]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(74).translation = [-66.365560000000002 110.60000000000001 -0.021846999999999998];  % mm
smiData.RigidTransform(74).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(74).axis = [1 0 0];
smiData.RigidTransform(74).ID = "F[MTzYZz5Mrcoif/lFG:-:MXMV9Eqn08eom2L6d]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(75).translation = [-66.365560000000002 118.40000000000001 -0.021846999999999998];  % mm
smiData.RigidTransform(75).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(75).axis = [-1 -0 -0];
smiData.RigidTransform(75).ID = "B[MZ5RLa4gP1alk6CCa:-:MXMV9Eqn08eom2L6d]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(76).translation = [-66.365560000000002 118.40000000000001 -0.021846999999999998];  % mm
smiData.RigidTransform(76).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(76).axis = [-1 -0 -0];
smiData.RigidTransform(76).ID = "F[MZ5RLa4gP1alk6CCa:-:MXMV9Eqn08eom2L6d]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(77).translation = [-24.127578 118.40000000000001 22.780628];  % mm
smiData.RigidTransform(77).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(77).axis = [1 0 0];
smiData.RigidTransform(77).ID = "B[Md/ldxY9ay6PXaDwt:-:MZ5RLa4gP1alk6CCa]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(78).translation = [-24.127578 118.40000000000001 22.780628];  % mm
smiData.RigidTransform(78).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(78).axis = [1 0 0];
smiData.RigidTransform(78).ID = "F[Md/ldxY9ay6PXaDwt:-:MZ5RLa4gP1alk6CCa]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(79).translation = [0 59.200000000000003 -0];  % mm
smiData.RigidTransform(79).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(79).axis = [1 0 0];
smiData.RigidTransform(79).ID = "B[MkpkMRHGYbJLFgS3x:-:Md/X0B0TzJAZZ0+Qc]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(80).translation = [0 59.200000000000003 -0];  % mm
smiData.RigidTransform(80).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(80).axis = [1 0 0];
smiData.RigidTransform(80).ID = "F[MkpkMRHGYbJLFgS3x:-:Md/X0B0TzJAZZ0+Qc]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(81).translation = [0 51.399999999999999 -0];  % mm
smiData.RigidTransform(81).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(81).axis = [1 0 0];
smiData.RigidTransform(81).ID = "B[MeoV3EVd8sqrVD15c:-:MkpkMRHGYbJLFgS3x]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(82).translation = [0 51.399999999999999 -0];  % mm
smiData.RigidTransform(82).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(82).axis = [1 0 0];
smiData.RigidTransform(82).ID = "F[MeoV3EVd8sqrVD15c:-:MkpkMRHGYbJLFgS3x]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(83).translation = [8.7268650000000001 43.5 -13.966096];  % mm
smiData.RigidTransform(83).angle = 1.9209009560558454;  % rad
smiData.RigidTransform(83).axis = [0.50536738601442821 0.50536738601442821 0.69943377835638421];
smiData.RigidTransform(83).ID = "B[M7MXx6AecKpl6IbJ8:-:Mt3FgXT9/aIAVV+Fe]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(84).translation = [8.7268650000000001 43.5 -13.966096];  % mm
smiData.RigidTransform(84).angle = 1.9209009560558454;  % rad
smiData.RigidTransform(84).axis = [0.50536738601442821 0.50536738601442821 0.69943377835638432];
smiData.RigidTransform(84).ID = "F[M7MXx6AecKpl6IbJ8:-:Mt3FgXT9/aIAVV+Fe]";

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(85).translation = [0 0 0];  % mm
smiData.RigidTransform(85).angle = 0;  % rad
smiData.RigidTransform(85).axis = [0 0 0];
smiData.RigidTransform(85).ID = "RootGround[Md/X0B0TzJAZZ0+Qc]";


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(34).mass = 0.0;
smiData.Solid(34).CoM = [0.0 0.0 0.0];
smiData.Solid(34).MoI = [0.0 0.0 0.0];
smiData.Solid(34).PoI = [0.0 0.0 0.0];
smiData.Solid(34).color = [0.0 0.0 0.0];
smiData.Solid(34).opacity = 0.0;
smiData.Solid(34).ID = "";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 2.13831719;  % g
smiData.Solid(1).CoM = [-52 84.900000000000006 37.309516000000002];  % mm
smiData.Solid(1).MoI = [237 16 237];  % g*mm^2
smiData.Solid(1).PoI = [0 0 0];  % g*mm^2
smiData.Solid(1).color = [0.301960784 0.301960784 0.301960784];
smiData.Solid(1).opacity = 1.000000000;
smiData.Solid(1).ID = "RPBD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 2.8994903400000003;  % g
smiData.Solid(2).CoM = [2.84328 122.30000000000001 6.2884009999999995];  % mm
smiData.Solid(2).MoI = [367 367 29.999999999999996];  % g*mm^2
smiData.Solid(2).PoI = [0 -19 0];  % g*mm^2
smiData.Solid(2).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(2).opacity = 1.000000000;
smiData.Solid(2).ID = "R+BD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 2.8994903400000003;  % g
smiData.Solid(3).CoM = [5.0241249999999997 43.5 -15.190726];  % mm
smiData.Solid(3).MoI = [335 367 62];  % g*mm^2
smiData.Solid(3).PoI = [0 101 0];  % g*mm^2
smiData.Solid(3).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(3).opacity = 1.000000000;
smiData.Solid(3).ID = "JkD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 5.33309034;  % g
smiData.Solid(4).CoM = [1.0513140000000001 114.5 -25.661384999999999];  % mm
smiData.Solid(4).MoI = [2210 2216 59.999999999999993];  % g*mm^2
smiData.Solid(4).PoI = [0 -121.00000000000001 0];  % g*mm^2
smiData.Solid(4).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(4).opacity = 1.000000000;
smiData.Solid(4).ID = "R7BD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 5.33309034;  % g
smiData.Solid(5).CoM = [-26 55.300000000000004 18.654758000000001];  % mm
smiData.Solid(5).MoI = [789 2216 1481];  % g*mm^2
smiData.Solid(5).PoI = [0 1025 0];  % g*mm^2
smiData.Solid(5).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(5).opacity = 1.000000000;
smiData.Solid(5).ID = "JeD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 3.5078903299999999;  % g
smiData.Solid(6).CoM = [48.550899999999999 106.7 17.609168];  % mm
smiData.Solid(6).MoI = [624 642 53];  % g*mm^2
smiData.Solid(6).PoI = [0 -103 0];  % g*mm^2
smiData.Solid(6).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(6).opacity = 1.000000000;
smiData.Solid(6).ID = "RyBD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 5.3328728999999999;  % g
smiData.Solid(7).CoM = [-23.220233 122.30000000000001 -25.212226000000001];  % mm
smiData.Solid(7).MoI = [2216 2216 54];  % g*mm^2
smiData.Solid(7).PoI = [0 41 0];  % g*mm^2
smiData.Solid(7).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(7).opacity = 1.000000000;
smiData.Solid(7).ID = "RYBD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 5.32916335;  % g
smiData.Solid(8).CoM = [17.536935 114.497495 14.139154];  % mm
smiData.Solid(8).MoI = [610 2215 1659];  % g*mm^2
smiData.Solid(8).PoI = [0 945 -0];  % g*mm^2
smiData.Solid(8).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(8).opacity = 1.000000000;
smiData.Solid(8).ID = "R1BD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 1.43350873;  % g
smiData.Solid(9).CoM = [10.048249999999999 27.599999999999998 -30.381453];  % mm
smiData.Solid(9).MoI = [74 11 74];  % g*mm^2
smiData.Solid(9).PoI = [0 0 0];  % g*mm^2
smiData.Solid(9).color = [0.301960784 0.301960784 0.301960784];
smiData.Solid(9).opacity = 1.000000000;
smiData.Solid(9).ID = "JYD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 2.8994903400000003;  % g
smiData.Solid(10).CoM = [-17.371834 3.8999999999999999 -32.888370000000002];  % mm
smiData.Solid(10).MoI = [151 367 246];  % g*mm^2
smiData.Solid(10).PoI = [0 -163 0];  % g*mm^2
smiData.Solid(10).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(10).opacity = 1.000000000;
smiData.Solid(10).ID = "JVD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 3.5078903399999999;  % g
smiData.Solid(11).CoM = [-59.182779999999994 106.7 18.643834999999999];  % mm
smiData.Solid(11).MoI = [564 642 113];  % g*mm^2
smiData.Solid(11).PoI = [0 -204 0];  % g*mm^2
smiData.Solid(11).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(11).opacity = 1.000000000;
smiData.Solid(11).ID = "RSBD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 5.32916335;  % g
smiData.Solid(12).CoM = [-18.751391999999999 11.702505 -16.405638];  % mm
smiData.Solid(12).MoI = [466 2215 1803];  % g*mm^2
smiData.Solid(12).PoI = [0 849 -0];  % g*mm^2
smiData.Solid(12).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(12).opacity = 1.000000000;
smiData.Solid(12).ID = "JMD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(13).mass = 5.33035982;  % g
smiData.Solid(13).CoM = [-38.214117000000002 122.301742 15.175908999999999];  % mm
smiData.Solid(13).MoI = [541 2215 1728];  % g*mm^2
smiData.Solid(13).PoI = [-0 -904 -0];  % g*mm^2
smiData.Solid(13).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(13).opacity = 1.000000000;
smiData.Solid(13).ID = "ReBD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(14).mass = 0.23891812099999998;  % g
smiData.Solid(14).CoM = [0 49.399999999999999 -0];  % mm
smiData.Solid(14).MoI = [1 2 1];  % g*mm^2
smiData.Solid(14).PoI = [0 0 0];  % g*mm^2
smiData.Solid(14).color = [0.301960784 0.301960784 0.301960784];
smiData.Solid(14).opacity = 1.000000000;
smiData.Solid(14).ID = "JhD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(15).mass = 3.5078903399999999;  % g
smiData.Solid(15).CoM = [59.192538000000006 19.5 18.647592];  % mm
smiData.Solid(15).MoI = [564 642 114];  % g*mm^2
smiData.Solid(15).PoI = [0 204 0];  % g*mm^2
smiData.Solid(15).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(15).opacity = 1.000000000;
smiData.Solid(15).ID = "J7D*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(16).mass = 5.33309034;  % g
smiData.Solid(16).CoM = [63.940473999999995 3.8999999999999999 -49.817332];  % mm
smiData.Solid(16).MoI = [745 2216 1525];  % g*mm^2
smiData.Solid(16).PoI = [0 1009 0];  % g*mm^2
smiData.Solid(16).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(16).opacity = 1.000000000;
smiData.Solid(16).ID = "J/D*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(17).mass = 5.9418774999999995;  % g
smiData.Solid(17).CoM = [78.352370000000008 11.700000000000001 -33.949328999999999];  % mm
smiData.Solid(17).MoI = [2726 3057 391];  % g*mm^2
smiData.Solid(17).PoI = [0 940 0];  % g*mm^2
smiData.Solid(17).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(17).opacity = 1.000000000;
smiData.Solid(17).ID = "J4D*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(18).mass = 2.8994903400000003;  % g
smiData.Solid(18).CoM = [-5.0241249999999997 82.699999999999989 15.190726];  % mm
smiData.Solid(18).MoI = [335 367 62];  % g*mm^2
smiData.Solid(18).PoI = [0 101 0];  % g*mm^2
smiData.Solid(18).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(18).opacity = 1.000000000;
smiData.Solid(18).ID = "RkBD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(19).mass = 5.9414903400000005;  % g
smiData.Solid(19).CoM = [-44.490470999999999 114.5 -28.613462999999999];  % mm
smiData.Solid(19).MoI = [1950 3056 1166];  % g*mm^2
smiData.Solid(19).PoI = [0 1446 0];  % g*mm^2
smiData.Solid(19).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(19).opacity = 1.000000000;
smiData.Solid(19).ID = "RVBD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(20).mass = 1.6724268499999999;  % g
smiData.Solid(20).CoM = [-52 37.400000000000006 37.309516000000002];  % mm
smiData.Solid(20).MoI = [116 13 116];  % g*mm^2
smiData.Solid(20).PoI = [0 0 0];  % g*mm^2
smiData.Solid(20).color = [0.301960784 0.301960784 0.301960784];
smiData.Solid(20).opacity = 1.000000000;
smiData.Solid(20).ID = "JbD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(21).mass = 5.1515391900000003;  % g
smiData.Solid(21).CoM = [-42.095878000000006 11.625321 -51.378131000000003];  % mm
smiData.Solid(21).MoI = [753 2021.9999999999998 1320];  % g*mm^2
smiData.Solid(21).PoI = [-8 -944 -10];  % g*mm^2
smiData.Solid(21).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(21).opacity = 1.000000000;
smiData.Solid(21).ID = "JSD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(22).mass = 3.5078903399999999;  % g
smiData.Solid(22).CoM = [-49.765076999999998 19.5 17.43478];  % mm
smiData.Solid(22).MoI = [635 642 43];  % g*mm^2
smiData.Solid(22).PoI = [0 67 0];  % g*mm^2
smiData.Solid(22).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(22).opacity = 1.000000000;
smiData.Solid(22).ID = "JPD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(23).mass = 5.32916335;  % g
smiData.Solid(23).CoM = [38.226877000000002 3.8974950000000002 -15.192386000000001];  % mm
smiData.Solid(23).MoI = [540 2215 1729];  % g*mm^2
smiData.Solid(23).PoI = [-0 -903 -0];  % g*mm^2
smiData.Solid(23).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(23).opacity = 1.000000000;
smiData.Solid(23).ID = "J1D*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(24).mass = 5.9414903400000005;  % g
smiData.Solid(24).CoM = [-58.046952999999995 3.8999999999999999 -36.869548999999999];  % mm
smiData.Solid(24).MoI = [2801 3056 315];  % g*mm^2
smiData.Solid(24).PoI = [0 -837 0];  % g*mm^2
smiData.Solid(24).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(24).opacity = 1.000000000;
smiData.Solid(24).ID = "JJD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(25).mass = 8.3750903399999999;  % g
smiData.Solid(25).CoM = [0 63.100000000000001 37.309516000000002];  % mm
smiData.Solid(25).MoI = [84 8512 8513];  % g*mm^2
smiData.Solid(25).PoI = [0 0 0];  % g*mm^2
smiData.Solid(25).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(25).opacity = 1.000000000;
smiData.Solid(25).ID = "JnD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(26).mass = 2.8994903400000003;  % g
smiData.Solid(26).CoM = [-23.825139 114.5 6.7834859999999999];  % mm
smiData.Solid(26).MoI = [368 367 29];  % g*mm^2
smiData.Solid(26).PoI = [0 6 0];  % g*mm^2
smiData.Solid(26).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(26).opacity = 1.000000000;
smiData.Solid(26).ID = "RbBD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(27).mass = 2.13831719;  % g
smiData.Solid(27).CoM = [52 41.300000000000004 37.309516000000002];  % mm
smiData.Solid(27).MoI = [237 16 237];  % g*mm^2
smiData.Solid(27).PoI = [0 0 0];  % g*mm^2
smiData.Solid(27).color = [0.301960784 0.301960784 0.301960784];
smiData.Solid(27).opacity = 1.000000000;
smiData.Solid(27).ID = "RFBD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(28).mass = 5.9414903400000005;  % g
smiData.Solid(28).CoM = [22.180574 122.30000000000001 -29.851175999999999];  % mm
smiData.Solid(28).MoI = [1842 3056 1275];  % g*mm^2
smiData.Solid(28).PoI = [0 -1471 0];  % g*mm^2
smiData.Solid(28).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(28).opacity = 1.000000000;
smiData.Solid(28).ID = "R4BD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(29).mass = 5.33309034;  % g
smiData.Solid(29).CoM = [26 70.900000000000006 18.654758000000001];  % mm
smiData.Solid(29).MoI = [789 2216 1481];  % g*mm^2
smiData.Solid(29).PoI = [0 -1025 0];  % g*mm^2
smiData.Solid(29).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(29).opacity = 1.000000000;
smiData.Solid(29).ID = "JtD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(30).mass = 0.23891812099999998;  % g
smiData.Solid(30).CoM = [0 76.799999999999997 -0];  % mm
smiData.Solid(30).MoI = [1 2 1];  % g*mm^2
smiData.Solid(30).PoI = [0 0 0];  % g*mm^2
smiData.Solid(30).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(30).opacity = 1.000000000;
smiData.Solid(30).ID = "RhBD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(31).mass = 2.89969301;  % g
smiData.Solid(31).CoM = [37.548290999999999 11.700000000000001 -31.717593000000001];  % mm
smiData.Solid(31).MoI = [137 368 260];  % g*mm^2
smiData.Solid(31).PoI = [0 158 0];  % g*mm^2
smiData.Solid(31).color = [0.917647059 0.917647059 0.917647059];
smiData.Solid(31).opacity = 1.000000000;
smiData.Solid(31).ID = "RCBD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(32).mass = 1.43350873;  % g
smiData.Solid(32).CoM = [-10.048249999999999 98.599999999999994 30.381453];  % mm
smiData.Solid(32).MoI = [74 11 74];  % g*mm^2
smiData.Solid(32).PoI = [0 0 0];  % g*mm^2
smiData.Solid(32).color = [0.301960784 0.301960784 0.301960784];
smiData.Solid(32).opacity = 1.000000000;
smiData.Solid(32).ID = "RnBD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(33).mass = 0.46589033699999999;  % g
smiData.Solid(33).CoM = [0 63.100000000000001 -0];  % mm
smiData.Solid(33).MoI = [4 4 4];  % g*mm^2
smiData.Solid(33).PoI = [0 0 0];  % g*mm^2
smiData.Solid(33).color = [0.301960784 0.301960784 0.301960784];
smiData.Solid(33).opacity = 1.000000000;
smiData.Solid(33).ID = "JqD*:*422e7aaaa7bf9dce380147a4";

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(34).mass = 1.6724268499999999;  % g
smiData.Solid(34).CoM = [52 88.799999999999997 37.309516000000002];  % mm
smiData.Solid(34).MoI = [116 13 116];  % g*mm^2
smiData.Solid(34).PoI = [0 0 0];  % g*mm^2
smiData.Solid(34).color = [0.301960784 0.301960784 0.301960784];
smiData.Solid(34).opacity = 1.000000000;
smiData.Solid(34).ID = "RvBD*:*422e7aaaa7bf9dce380147a4";


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(26).Rz.Pos = 0.0;
smiData.RevoluteJoint(26).ID = "";

smiData.RevoluteJoint(1).Rz.Pos = 18.351751123322874;  % deg
smiData.RevoluteJoint(1).ID = "[MTzYZz5Mrcoif/lFG:-:M+2eHVvnKNB1MxLZL]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.RevoluteJoint(2).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(2).ID = "[M/CiqqQpBnCskr4+V:-:M3s1jUyctnM5YbsmK]";

smiData.RevoluteJoint(3).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(3).ID = "[MKJuudjXPn7BM+e8Z:-:M/CiqqQpBnCskr4+V]";

smiData.RevoluteJoint(4).Rz.Pos = 12.419452032895821;  % deg
smiData.RevoluteJoint(4).ID = "[MWHMBJWHd63yzRE4j:-:M02Z7wFD2+BwEdrh+]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.RevoluteJoint(5).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(5).ID = "[MkE/8tQ2r7nvBIxz3:-:M1/w5YNcix31CdHRM]";

smiData.RevoluteJoint(6).Rz.Pos = 13.137575037975697;  % deg
smiData.RevoluteJoint(6).ID = "[MsVyb6yZkElm/xbGR:-:M4F6ctRcHkFPCskYT]";

smiData.RevoluteJoint(7).Rz.Pos = 18.175626669971912;  % deg
smiData.RevoluteJoint(7).ID = "[MeoV3EVd8sqrVD15c:-:M7MXx6AecKpl6IbJ8]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.RevoluteJoint(8).Rz.Pos = 105.88315367535998;  % deg
smiData.RevoluteJoint(8).ID = "[MC7DNYQX7c+ZrnvzA:-:MCjqOdb0ZHFImRkI9]";

smiData.RevoluteJoint(9).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(9).ID = "[MLXebeq1y6JZgNbcM:-:MC7DNYQX7c+ZrnvzA]";

smiData.RevoluteJoint(10).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(10).ID = "[MRqRTxAU0QSWouB90:-:MC7DNYQX7c+ZrnvzA]";

smiData.RevoluteJoint(11).Rz.Pos = -14.711925027507759;  % deg
smiData.RevoluteJoint(11).ID = "[MWHMBJWHd63yzRE4j:-:MC7DNYQX7c+ZrnvzA]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.RevoluteJoint(12).Rz.Pos = 96.705083591187744;  % deg
smiData.RevoluteJoint(12).ID = "[MZ5RLa4gP1alk6CCa:-:MC7DNYQX7c+ZrnvzA]";

smiData.RevoluteJoint(13).Rz.Pos = -18.175626669971912;  % deg
smiData.RevoluteJoint(13).ID = "[Mt3FgXT9/aIAVV+Fe:-:MEhe6EvhF50paFOVB]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.RevoluteJoint(14).Rz.Pos = -89.999999999999986;  % deg
smiData.RevoluteJoint(14).ID = "[MLXebeq1y6JZgNbcM:-:MHmAIyT7gTm8rVmh3]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.RevoluteJoint(15).Rz.Pos = -16.529106271062656;  % deg
smiData.RevoluteJoint(15).ID = "[MIw35ywh72LKi7AbB:-:MKJuudjXPn7BM+e8Z]";

smiData.RevoluteJoint(16).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(16).ID = "[MJkF9MQs/yTioq4PS:-:MXzZbBmkDaKQkFjS8]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.RevoluteJoint(17).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(17).ID = "[MkE/8tQ2r7nvBIxz3:-:MJkF9MQs/yTioq4PS]";

smiData.RevoluteJoint(18).Rz.Pos = -13.388395821707642;  % deg
smiData.RevoluteJoint(18).ID = "[MJkF9MQs/yTioq4PS:-:Mu4dm2/molVK9BjjF]";

smiData.RevoluteJoint(19).Rz.Pos = -0.86928521416551718;  % deg
smiData.RevoluteJoint(19).ID = "[MkE/8tQ2r7nvBIxz3:-:MKJuudjXPn7BM+e8Z]";

smiData.RevoluteJoint(20).Rz.Pos = -11.491054639066441;  % deg
smiData.RevoluteJoint(20).ID = "[MKJuudjXPn7BM+e8Z:-:MsVyb6yZkElm/xbGR]";

smiData.RevoluteJoint(21).Rz.Pos = 0;  % deg
smiData.RevoluteJoint(21).ID = "[MynBVfUU+E1te4mPM:-:MKJuudjXPn7BM+e8Z]";

smiData.RevoluteJoint(22).Rz.Pos = -75.834368993548637;  % deg
smiData.RevoluteJoint(22).ID = "[Mu4dm2/molVK9BjjF:-:MRdTCvrtZxh/K4wT1]";

smiData.RevoluteJoint(23).Rz.Pos = -0.0010559445974075152;  % deg
smiData.RevoluteJoint(23).ID = "[MSgXRWfTiK9gAcPPd:-:MXMV9Eqn08eom2L6d]";

smiData.RevoluteJoint(24).Rz.Pos = -13.935300574753247;  % deg
smiData.RevoluteJoint(24).ID = "[MTzYZz5Mrcoif/lFG:-:MXMV9Eqn08eom2L6d]";

smiData.RevoluteJoint(25).Rz.Pos = -0.0038399519937902691;  % deg
smiData.RevoluteJoint(25).ID = "[MZ5RLa4gP1alk6CCa:-:MXMV9Eqn08eom2L6d]";

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.RevoluteJoint(26).Rz.Pos = -0.0027840073963826904;  % deg
smiData.RevoluteJoint(26).ID = "[Md/ldxY9ay6PXaDwt:-:MZ5RLa4gP1alk6CCa]";

